
SicControl <- R6Class("SicControl",
  inherit = SicData,
  public = list(
    initialize = function() {
    },
    get_bytes = function() {
      return(NULL)
    },
    init_with = function(bs, dims) {
    }
  )
)
